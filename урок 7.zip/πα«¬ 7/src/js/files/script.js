// Підключення функціоналу "Чертоги Фрілансера"
import { isMobile } from "./functions.js";
// Підключення списку активних модулів
import { flsModules } from "./modules.js";

const creditCardInput = document.querySelector("#credit-card");
let errorBlock = null; // Создаем переменную для хранения элемента ошибки

// Функция для форматирования номера карты
function formatCardNumber() {
    let cardNumber = this.value;
    cardNumber = cardNumber.replace(/\D/g, "");
    cardNumber = cardNumber.replace(/(.{4})/g, "$1 ").trim();
    this.value = cardNumber;
    if (cardNumber.length > 22) {
        this.value = cardNumber.slice(0, 22);
    }
}

// Обработчик события input для поля ввода номера карты
creditCardInput.addEventListener("input", formatCardNumber);

// Обработчик события blur для поля ввода номера карты
creditCardInput.addEventListener("blur", function () {
    const cardNumber = this.value;
    if (cardNumber.length > 0 && cardNumber.length < 19) { // Проверка на непустое поле и неправильную длину
        if (!errorBlock) { // Проверяем, существует ли уже блок ошибки
            errorBlock = document.createElement("div");
            errorBlock.textContent = "слишком короткий номер";
            errorBlock.classList.add("error");
            this.parentNode.appendChild(errorBlock);
        }
    } else {
        if (errorBlock) {
            errorBlock.remove();
            errorBlock = null; // Сбрасываем переменную, чтобы создать новый блок ошибки при необходимости
        }
    }
});


const dateCard = document.querySelector('#expiration-date');
const inputDate = new Inputmask("99/99", {
    placeholder: "00/00",
    oncomplete: function () {
        const value = this.value;
        const parts = value.split('/');
        const month = parseInt(parts[0]);
        const year = parseInt(parts[1]);
        const currentYear = new Date().getFullYear() % 100;
        const currentMonth = new Date().getMonth() + 1;

        if ((year > currentYear) || (year == currentYear && month <= currentMonth && month > 0) || month == 0) {
            const errorBlock = document.createElement("div");
            errorBlock.textContent = "неверная дата";
            errorBlock.classList.add("error");
            this.parentNode.appendChild(errorBlock);
            this.value = '';
        }
        this.blur();
    }
}).mask(document.getElementById("expiration-date"));
dateCard.addEventListener("focus", function () {
    const errorBlock = this.parentNode.querySelector(".error");
    if (errorBlock) {
        errorBlock.remove();
    }
});

const cvvInput = document.querySelector('.input__card-code');

// Обработчик события keypress для поля ввода CVV
cvvInput.addEventListener('keypress', function(event) {
    // Получаем код клавиши
    const keyCode = event.keyCode || event.which;

    // Коды клавиш для цифр: 48-57
    if (keyCode < 48 || keyCode > 57) {
        // Предотвращаем добавление символа в поле ввода
        event.preventDefault();
    }
});

// Обработчик события input для поля ввода CVV
cvvInput.addEventListener('input', function(event) {
    const cvcValue = this.value.trim();
    
    // Удаление предыдущего блока с сообщением об ошибке
    const errorBlock = this.parentNode.querySelector(".error");
    if (errorBlock) {
        errorBlock.remove();
    }

    // Проверка, что введены только цифры и не больше 3 символов
    if (/^\d{0,2}$/.test(cvcValue)) {
        const errorBlock = document.createElement("div");
        errorBlock.textContent = "Ожидается ввод ровно 3 цифр";
        errorBlock.classList.add("error");
        this.parentNode.appendChild(errorBlock);
    } else if (cvcValue.length > 3) {
        // Если длина превышает 3 символа, не даем ввести новый символ
        this.value = cvcValue.slice(0, 3);
    }
});



































//========================================================================================================================================================
// document.addEventListener("DOMContentLoaded", function() {
// 	function removeElement(item, block) {
// 		block.addEventListener("focus", function () {
// 			const errorElements = document.querySelectorAll(item);
// 			errorElements.forEach(element => {
// 				element.remove();
// 			});
// 		});
	
// 	}
	
	
// 	const creditCardInput = document.querySelector("#credit-card");
	
// 	creditCardInput.addEventListener("input", function () {
// 		let cardNumber = this.value;
// 		cardNumber = cardNumber.replace(/\D/g, "");
// 		cardNumber = cardNumber.replace(/(.{4})/g, "$1 ").trim();
// 		this.value = cardNumber;
// 		if (cardNumber.length > 22) {
// 			this.value = cardNumber.slice(0, 22);
// 		}
// 	});
	
	
// 	creditCardInput.addEventListener("blur", function () {
// 		const cardNumber = this.value;
// 		if (cardNumber.length < 19) {
// 			const errorBlock = document.createElement("div");
// 			errorBlock.textContent = "слишком короткий номер";
// 			errorBlock.classList.add("error");
// 			this.parentNode.appendChild(errorBlock);
// 		}
	
	
// 	});
	
	
	
	
// 	removeElement(".error", creditCardInput);
	
	
// 	const dateCard = document.querySelector('#expiration-date');
// 	const inputDate = new Inputmask("99/99", {
// 		placeholder: "00/00",
// 		oncomplete: function () {
// 			const value = this.value;
// 			const parts = value.split('/');
// 			const month = parseInt(parts[0]);
// 			const year = parseInt(parts[1]);
// 			const currentYear = new Date().getFullYear() % 100;
// 			const currentMonth = new Date().getMonth() + 1;
	
// 			if ((year > currentYear) || (year == currentYear && month <= currentMonth && month > 0) || month == 0) {
// 				const errorBlock = document.createElement("div");
// 				errorBlock.textContent = "неверная дата";
// 				errorBlock.classList.add("error");
// 				this.parentNode.appendChild(errorBlock);
// 				this.value = '';
// 			}
// 			this.blur();
// 		}
// 	}).mask(document.getElementById("expiration-date"));
	
	
// 	const cvvInput = document.querySelector('.input__card-code');
// 	function checkCVVInput(event) {
// 		const cvcValue = this.value.trim();
		
// 		const errorBlock = this.parentNode.querySelector(".error");
// 		if (errorBlock) {
// 			errorBlock.remove();
// 		}
	
// 		const onlyDigitsRegex = /^\d*$/;
	
	
// 		if (!onlyDigitsRegex.test(cvcValue) || cvcValue.length !== 3) {
// 			const errorBlock = document.createElement("div");
// 			errorBlock.textContent = "Ожидается ввод ровно 3 цифр";
// 			errorBlock.classList.add("error");
// 			this.parentNode.appendChild(errorBlock);
// 		}
// 	}
	
	
// 	cvvInput.addEventListener("blur", checkCVVInput);
// 	removeElement(".error", cvvInput);
	
	
	
// 	const payButton = document.getElementById('pay-button');
// 	const expirationDateInput = document.getElementById('expiration-date');
// 	const emailInput = document.getElementById('email');
// 	function checkFormValidity() {
// 		const creditCardValue = creditCardInput.value.trim();
// 		const expirationDateValue = expirationDateInput.value.trim();
// 		const cvvValue = cvvInput.value.trim();
// 		const emailValue = emailInput.value.trim();
// 		const isCreditCardValid = /\b\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{4}\b/.test(creditCardValue);
// 		const isExpirationDateValid = /\b\d{2}\/\d{2}\b/.test(expirationDateValue);
// 		const isCVVValid = /^\d{3}$/.test(cvvValue);
// 		const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue);
// 		if (isCreditCardValid && isExpirationDateValid && isCVVValid && isEmailValid) {
// 			payButton.removeAttribute('disabled');
// 			payButton.classList.add(".active")
// 		} else {
// 			payButton.setAttribute('disabled', 'disabled');
// 		}
// 	}
	
// 	creditCardInput.addEventListener('input', checkFormValidity);
// 	expirationDateInput.addEventListener('input', checkFormValidity);
// 	cvvInput.addEventListener('input', checkFormValidity);
// 	emailInput.addEventListener('input', checkFormValidity);
// 	});